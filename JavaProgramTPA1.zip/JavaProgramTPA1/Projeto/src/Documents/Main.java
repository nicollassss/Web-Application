
package Documents;

import java.util.Scanner;

public class Main {

	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Digite o seu nome: ");
		String nome = scanner.nextLine();
		System.out.print("Digite sua idade: ");
		int idade = scanner.nextInt();
		System.out.print("Digite o seu sexo M/F: ");
		char sexo = scanner.next().charAt(0);
		System.out.print("Digite sua altura por metros, por ex: 1.75: ");
		double altura = scanner.nextDouble();
		scanner.nextLine();
		System.out.print("Digite o seu endere�o: ");
		String endere�o = scanner.nextLine();
		System.out.print("Escreva anota��es se achar necess�rio: ");
		String observacoes = scanner.nextLine();
		
		if
		(observacoes.length() > 80) {
			observacoes =
					observacoes.substring(0,80);
		}
		
		System.out.print("Digite o seu peso: ");
		double peso = scanner.nextDouble();
		
		double imc = calcularIMC(peso, altura);
		
		System.out.println("\n--- Dados do Aluno ---");
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Sexo: " + (sexo == 'M' ? "Masculino" : "Feminino"));
        System.out.println("Altura: " + altura + " metros");
        System.out.println("Endere�o: " + endere�o);
        System.out.println("Observa��es: " + observacoes);
        System.out.println("Peso: " + peso + " kg");
        System.out.println("IMC: " + String.format("%.2f", imc)); // Formata o IMC com 2 casas decimais

        // fecha scanner
        scanner.close();
	}
    public static double  calcularIMC(double peso, double altura) {
    	return peso / (altura * altura);
    }
	
}
